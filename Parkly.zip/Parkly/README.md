# Parkly - Android parking finder

Kotlin + Jetpack Compose + Google Maps. Flow: Welcome -> Sign in / Sign up -> Map of nearby parking.

## Run it
1. Install Android Studio (Koala or newer) and open this `Parkly` folder.
2. In Google Cloud Console, create a project, enable **Maps SDK for Android**, and create an API key.
3. Copy `local.properties.example` to `local.properties` and paste your key as `MAPS_API_KEY=...`
   (keep the `sdk.dir=` line Android Studio adds).
4. Let Gradle sync, then press Run on a phone or emulator (set a location in the emulator's Extended controls).

## What works now
- Welcome screen with logo and animation, sign in / sign up form (validation only)
- Live location, parking markers (green = free, red = full), radius chips: 200 m, 300 m, 400 m, **500 m (default)**, 1 km, 5 km
- Radius circle on the map, nearest-first spot cards, Navigate button that opens Google Maps directions

## Still demo-only (next steps)
- **Parking data:** `data/ParkingRepository.kt` generates sample spots around the user. Replace `spotsAround()` with a Firestore query.
- **Accounts:** `ui/AuthScreen.kt` only validates input. Add Firebase Auth in the button handler.
- **Reservations:** not built yet.
