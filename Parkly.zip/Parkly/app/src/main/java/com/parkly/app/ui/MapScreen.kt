package com.parkly.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.Circle
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import com.parkly.app.data.ParkingRepository
import com.parkly.app.data.ParkingSpot
import kotlin.coroutines.resume
import kotlin.math.ln
import kotlinx.coroutines.suspendCancellableCoroutine

/** Used only when the user denies location access or the location can't be read. */
private val FALLBACK = LatLng(25.3960, 68.3578)

private val RADII = listOf(200, 300, 400, 500, 1000, 5000)
private const val DEFAULT_RADIUS = 500

private fun radiusLabel(m: Int) = if (m >= 1000) "${m / 1000} km" else "$m m"

private fun hasLocationPermission(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
private suspend fun fetchLocation(ctx: Context): LatLng? = suspendCancellableCoroutine { cont ->
    LocationServices.getFusedLocationProviderClient(ctx)
        .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
        .addOnSuccessListener { l -> cont.resume(l?.let { LatLng(it.latitude, it.longitude) }) }
        .addOnFailureListener { cont.resume(null) }
}

/** Zoom level that fits a circle of the given radius on a phone screen. */
private fun zoomFor(radiusM: Int): Float = (15.7 - ln(radiusM / 500.0) / ln(2.0)).toFloat()

@Composable
fun MapScreen() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasLocationPermission(ctx)) }
    var denied by remember { mutableStateOf(false) }
    var me by remember { mutableStateOf<LatLng?>(null) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        granted = res.values.any { it }
        denied = !granted
    }

    LaunchedEffect(granted, denied) {
        when {
            granted -> me = fetchLocation(ctx) ?: FALLBACK
            denied -> me = FALLBACK
        }
    }

    val center = me
    when {
        center != null -> ParkingMap(center, locationEnabled = granted)
        granted -> Loading()
        else -> PermissionPrompt(onAllow = {
            launcher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        })
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize().background(Asphalt), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = LineYellow)
            Spacer(Modifier.height(16.dp))
            Text("Finding your location...", color = Color.White)
        }
    }
}

@Composable
private fun PermissionPrompt(onAllow: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Asphalt).systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Allow location to see parking near you",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Parkly uses your location only to show free spaces within walking distance. " +
                "You can change the search radius at any time.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.78f)
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onAllow,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Allow location", style = MaterialTheme.typography.labelLarge) }
    }
}

@Composable
private fun ParkingMap(center: LatLng, locationEnabled: Boolean) {
    var radius by rememberSaveable { mutableIntStateOf(DEFAULT_RADIUS) }
    var selectedId by remember { mutableStateOf<String?>(null) }

    val all = remember(center) { ParkingRepository.spotsAround(center) }
    val spots = remember(all, radius) {
        all.filter { it.distanceM <= radius }.sortedBy { it.distanceM }
    }

    val camera = rememberCameraPositionState()
    LaunchedEffect(center, radius) {
        camera.animate(CameraUpdateFactory.newLatLngZoom(center, zoomFor(radius)))
    }
    LaunchedEffect(selectedId) {
        spots.find { it.id == selectedId }?.let {
            camera.animate(CameraUpdateFactory.newLatLngZoom(it.position, 17f))
        }
    }

    Box(Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = camera,
            properties = MapProperties(isMyLocationEnabled = locationEnabled),
            uiSettings = MapUiSettings(zoomControlsEnabled = false, myLocationButtonEnabled = false)
        ) {
            Circle(
                center = center,
                radius = radius.toDouble(),
                strokeColor = ParkBlue,
                strokeWidth = 3f,
                fillColor = ParkBlue.copy(alpha = 0.10f)
            )
            spots.forEach { s ->
                Marker(
                    state = rememberMarkerState(key = s.id, position = s.position),
                    title = s.name,
                    snippet = if (s.freeSlots > 0) "${s.freeSlots} free" else "Full",
                    icon = BitmapDescriptorFactory.defaultMarker(
                        if (s.freeSlots > 0) BitmapDescriptorFactory.HUE_GREEN
                        else BitmapDescriptorFactory.HUE_RED
                    ),
                    onClick = { selectedId = s.id; false }
                )
            }
        }

        // Header
        Surface(
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(16.dp),
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 6.dp,
            color = Color.White
        ) {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("Parking near you", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${spots.size} spots within ${radiusLabel(radius)}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Radius chips + results
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(RADII) { r ->
                    FilterChip(
                        selected = r == radius,
                        onClick = { radius = r; selectedId = null },
                        label = { Text(radiusLabel(r)) }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            if (spots.isEmpty()) {
                Surface(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    shadowElevation = 8.dp
                ) {
                    Text(
                        "No parking within ${radiusLabel(radius)}. Try a wider radius.",
                        modifier = Modifier.padding(20.dp),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(spots, key = { it.id }) { s ->
                        SpotCard(s, selected = s.id == selectedId, onClick = { selectedId = s.id })
                    }
                }
            }
        }
    }
}

@Composable
private fun SpotCard(spot: ParkingSpot, selected: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val free = spot.freeSlots > 0
    Surface(
        modifier = Modifier.width(280.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = if (selected) 12.dp else 6.dp,
        color = Color.White
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    spot.name,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = (if (free) FreeGreen else FullRed).copy(alpha = 0.14f)
                ) {
                    Text(
                        if (free) "${spot.freeSlots} free" else "Full",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = if (free) FreeGreen else FullRed,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "${spot.distanceM} m away  |  Rs ${spot.pricePerHour}/hour",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { navigateTo(ctx, spot.position) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Navigate") }
        }
    }
}

private fun navigateTo(ctx: Context, p: LatLng) {
    val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${p.latitude},${p.longitude}&mode=d"))
        .setPackage("com.google.android.apps.maps")
    try {
        ctx.startActivity(nav)
    } catch (e: ActivityNotFoundException) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${p.latitude},${p.longitude}?q=${p.latitude},${p.longitude}")))
    }
}
