package com.parkly.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Asphalt = Color(0xFF1B2430)
val ParkBlue = Color(0xFF1D5FD1)
val BayWhite = Color(0xFFF7F8FA)
val FreeGreen = Color(0xFF1FA971)
val FullRed = Color(0xFFD9483B)
val LineYellow = Color(0xFFF2B705)

private val colors = lightColorScheme(
    primary = ParkBlue,
    onPrimary = Color.White,
    background = BayWhite,
    surface = Color.White,
    onSurface = Asphalt,
    error = FullRed
)

private val type = Typography(
    headlineLarge = TextStyle(fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp),
    headlineSmall = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
)

@Composable
fun ParklyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = type, content = content)
}
