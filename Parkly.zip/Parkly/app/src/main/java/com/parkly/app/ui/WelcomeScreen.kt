package com.parkly.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(1700, easing = FastOutSlowInEasing))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Asphalt)
            .systemBarsPadding()
            .padding(horizontal = 28.dp, vertical = 24.dp)
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Canvas(Modifier.fillMaxSize()) {
                val bays = 4
                val bayW = size.width / bays
                val top = size.height * 0.12f
                val bottom = size.height * 0.86f
                val line = Color.White.copy(alpha = 0.55f)

                // the free bay fills with green as the car arrives
                drawRect(
                    FreeGreen.copy(alpha = 0.28f * progress.value),
                    topLeft = Offset(bayW, top),
                    size = Size(bayW, bottom - top)
                )
                for (i in 0..bays) {
                    drawLine(line, Offset(i * bayW, top), Offset(i * bayW, bottom), strokeWidth = 6f)
                }
                drawLine(line, Offset(0f, top), Offset(size.width, top), strokeWidth = 6f)

                val carW = bayW * 0.62f
                val carH = bayW * 1.2f
                val carR = CornerRadius(carW * 0.22f)
                val slate = Color(0xFF3A4757)
                val endY = top + (bottom - top - carH) / 2
                for (i in listOf(0, 2)) {
                    drawRoundRect(
                        slate,
                        Offset(i * bayW + (bayW - carW) / 2, endY),
                        Size(carW, carH), carR
                    )
                }
                val y = size.height + (endY - size.height) * progress.value
                drawRoundRect(ParkBlue, Offset(bayW + (bayW - carW) / 2, y), Size(carW, carH), carR)
            }
        }

        Text("Parkly", style = MaterialTheme.typography.headlineLarge, color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text(
            "Find a free parking space near you, in seconds.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.78f)
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LineYellow, contentColor = Asphalt)
        ) {
            Text("Get started", style = MaterialTheme.typography.labelLarge)
        }
    }
}
