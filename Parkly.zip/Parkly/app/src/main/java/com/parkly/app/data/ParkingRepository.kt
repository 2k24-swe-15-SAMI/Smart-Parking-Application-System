package com.parkly.app.data

import android.location.Location
import com.google.android.gms.maps.model.LatLng
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Sample data source. It scatters demo parking lots within 5 km of the given point so the app
 * works anywhere. To use real data, replace [spotsAround] with a Firestore / REST query that
 * returns ParkingSpot objects (see README).
 */
object ParkingRepository {

    private val names = listOf(
        "Central Plaza Parking", "Bazaar Street Lot", "Station Road Garage", "City Mall Parking",
        "Riverside Lot", "Clock Tower Parking", "Hospital Visitors Lot", "Market Gate Parking",
        "University Road Lot", "Garden Park Parking", "Old Town Garage", "Airport Road Lot"
    )

    fun spotsAround(center: LatLng, count: Int = 36): List<ParkingSpot> {
        val rnd = Random(42)
        return List(count) { i ->
            val dist = 60 + rnd.nextDouble() * 4900
            val bearing = rnd.nextDouble() * 2 * PI
            val lat = center.latitude + dist * cos(bearing) / 111_320.0
            val lng = center.longitude +
                dist * sin(bearing) / (111_320.0 * cos(Math.toRadians(center.latitude)))
            val total = 10 + rnd.nextInt(90)
            val free = if (rnd.nextInt(5) == 0) 0 else rnd.nextInt(total) + 1
            val pos = LatLng(lat, lng)
            ParkingSpot(
                id = "p$i",
                name = names[i % names.size] + if (i >= names.size) " ${i / names.size + 1}" else "",
                position = pos,
                pricePerHour = 20 + rnd.nextInt(8) * 10,
                totalSlots = total,
                freeSlots = free,
                distanceM = distanceBetween(center, pos).toInt()
            )
        }
    }

    fun distanceBetween(a: LatLng, b: LatLng): Float {
        val r = FloatArray(1)
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, r)
        return r[0]
    }
}
