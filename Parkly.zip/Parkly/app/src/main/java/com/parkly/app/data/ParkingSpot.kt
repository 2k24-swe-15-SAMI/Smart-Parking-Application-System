package com.parkly.app.data

import com.google.android.gms.maps.model.LatLng

data class ParkingSpot(
    val id: String,
    val name: String,
    val position: LatLng,
    val pricePerHour: Int,
    val totalSlots: Int,
    val freeSlots: Int,
    val distanceM: Int
)
