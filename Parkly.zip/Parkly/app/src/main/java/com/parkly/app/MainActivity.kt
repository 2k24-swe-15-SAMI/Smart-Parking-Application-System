package com.parkly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.parkly.app.ui.AuthScreen
import com.parkly.app.ui.MapScreen
import com.parkly.app.ui.ParklyTheme
import com.parkly.app.ui.WelcomeScreen

enum class Screen { Welcome, Auth, Map }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ParklyTheme { App() }
        }
    }
}

@Composable
fun App() {
    var screen by rememberSaveable { mutableStateOf(Screen.Welcome) }
    when (screen) {
        Screen.Welcome -> WelcomeScreen(onStart = { screen = Screen.Auth })
        Screen.Auth -> AuthScreen(onDone = { screen = Screen.Map })
        Screen.Map -> MapScreen()
    }
}
